/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;
import java.sql.*;
/**
 *
 * @author rabiu
 */
public class createTable {
     public static void main(String[] args) {
 Connection con = connectDB.getConnection();
 Statement stmt = null;
 String createString;
 createString = "CREATE TABLE if not exists USERTESTING (\n"
 + " empID INTEGER PRIMARY KEY,\n"
 + " empName VARCHAR (15),\n"
 + " empJob VARCHAR (15),\n"
+ " empSal INT (11)\n" + ") ;";
 try {
 stmt = con.createStatement();
 stmt.executeUpdate(createString);
 con.setAutoCommit(false);
 con.commit();
 } catch (SQLException ex) {
 System.err.println("SQLException: " + ex.getMessage());
 } finally {
 if (stmt != null) {
 try {
 stmt.close();
 } catch (SQLException e) {
 System.err.println("SQLException: " + e.getMessage());
 }
 }
 if (con != null) {
 try {
 con.close();
 } catch (SQLException e) {
 System.err.println("SQLException: " + e.getMessage());

    }
 }
 }
 }
    
}
